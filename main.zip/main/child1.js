var  c = require('./parent/parent2/child2');
c.dump();

var b = require('./parent/child');
b.dump();

console.log(module.parent.filename);
