exports.dump = function () {
  console.log(module.parent.filename);
console.log("I am child2");
}
