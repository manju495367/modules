var child2 = require('./parent2/child2');
//child2.dump();

exports.dump = function () {
  console.log(module.parent.filename);
console.log("I am child");
}
